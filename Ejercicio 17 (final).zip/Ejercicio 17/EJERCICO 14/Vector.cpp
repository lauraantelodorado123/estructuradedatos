#include "StdAfx.h"
#include "Vector.h"
#include <iostream>
#define NMAX 10

Vector::Vector(void)//constructor
{
	vector[NMAX]=0;
	tamano=0;
}
Vector::~Vector(void)//destructor
{
}

	int Vector::Get_tamano()
	{
	return tamano;
	
	}
	void Vector::Set_tamano(int tam)
	{ tamano= tam;

	}
	int Vector::Get_vector(int posicion)
	{
	return vector[posicion];

	}
	void Vector::Set_vector(int posicion, int elemento) 
	{
	vector[posicion]=elemento;
	
	}
	void Vector::Incrementar()
	{
	tamano++;
	
	}
	void Vector::Decrementar()
	{
	tamano--;

	}
	bool Vector::Vacio_vector()
	{
	if(tamano==0)
	{return true;}
	else
	{return false;}
	}
	bool Vector::Lleno_vector()
	{if(tamano==(NMAX-1))
	{return true;}
	else
	{return false;}
	}

	bool Vector::Insertar(int elemento, int posicion)
	{
	if((posicion<0)&&(posicion>tamano))
	    {return false;}
	else
		{
		if(Lleno_vector()==true) 
			{return false;}
		else
			{	
			    int i=Get_tamano();
				while(i>posicion)
				{
				 vector[i]=vector[i-1];
				 i--;
				}
				vector[posicion]=elemento;
				
				return true;
			}
		}
	}

	bool Vector::Buscar(int elem, int &posicion)
	{
	for(int i =0; i<tamano; i++)
	{if(elem==vector[i])
	{posicion= i;
	return true;
	}
	}
	return false;
	}
	void Vector::ordenarVector()
	{int n=tamano;

	int aux;
	for(int i=0; i<n; i++)
	{for(int i=0; i<n-1; i++)
	{if(vector[i]>vector[i+1])
	{aux=vector[i];
	vector[i]=vector[i+1];
	vector[i+1]= aux;
	}
	}
	}
	}
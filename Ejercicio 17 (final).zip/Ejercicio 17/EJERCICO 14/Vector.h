
#pragma once
#define NMAX 10

class Vector
{private:
int vector[NMAX];
int tamano;

public:
	Vector(void);//constructor
	~Vector(void);//destructor

	int Get_tamano();
	void Set_tamano(int tam);

	int Get_vector(int posicion);
	void Set_vector(int posicion, int elemento); 
	void Incrementar();
	void Decrementar();
	bool Vacio_vector();
	bool Lleno_vector();
	bool Insertar(int elemento, int posicion);
	
	bool Buscar(int elem, int &posicion);
	
	void ordenarVector();

};
